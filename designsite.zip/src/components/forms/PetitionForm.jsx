import React from 'react';

function PetitionForm() {
    return (
        <>
            Form
        </>
    );
}

export default PetitionForm;
